/**
 * ENGG1110 Problem Solving by Programming
 *
 * Course Project
 *
 * I declare that the project here submitted is original
 * except for source material explicitly acknowledged,
 * and that the same or closely related material has not been
 * previously submitted for another course.
 * I also acknowledge that I am aware of University policy and
 * regulations on honesty in academic work, and of the disciplinary
 * guidelines and procedures applicable to breaches of such
 * policy and regulations, as contained in the website.
 *
 * University Guideline on Academic Honesty:
 *   https://www.cuhk.edu.hk/policy/academichonesty/
 *
 * Student Name  : SAHA, Anujit
 * Student ID    : 1155163076
 * Class/Section :  C
 * Date          :  01 December,2022
 */

#include <stdio.h>
/* NO other header files are allowed */
/* NO global variables are allowed */



/* Display the game board and the unused numbers list on the screen.
   You are required to exactly follow the output format stated in the project specification.
   IMPORTANT: Using other output formats will result in mark deduction. */
void printInfo(int gameBoard[3][3], int numbers[9]) {
    int i,j,k;
    for(i=0;i<3;i++){
        printf("\n | ");
        for(j=0;j<3;j++){
            if(gameBoard[i][j]==0)
                printf(" | ");
            else
                printf("%d| ",gameBoard[i][j]);
        }
    }

  printf("\nUnused numbers:\n");
  for(k=0;k<=8;k++){
    if(numbers[k]==0)
    printf("%d ",k+1);
  }
}


/* Read the user inputs to place a number on the game board.
   In Project Part 1, you can assume that the user inputs must be valid. */
void placeNumber(int gameBoard[3][3], int numbers[9], int currentPlayer) {
    int position;
    int number;

    if (currentPlayer == 1){
        printf("\n ### Player %d 's turn ###\n ",currentPlayer);
  }
   else{
        printf("\n### Computer's turn ###\nComputer Placed the number!\n");

   }
    //Make a boolean variable checking if user input is valid
    //If input is invalid run the loop asking for input
    //If input valid go through for the nex

    int userInputIsValid;

    if(currentPlayer==1){

        while(userInputIsValid != 1){
            printf("Input the position: \n ");
            scanf("%d",&position);
            printf("Input the number:\n ");
            scanf("%d",&number);

            //Find the corresponding rows and columns from user input position
            int row, column;

            if (position == 7 || position == 8 || position == 9)
                row = 0;
            else if (position == 4 || position == 5 || position == 6)
                row = 1;
            else if (position == 1 || position == 2 || position == 3)
                row = 2;

            if (position == 7 || position == 4 || position == 1)
                column = 0;
            else if (position == 8 || position == 5 || position == 2)
                column = 1;
            else if (position == 9 || position == 6 || position == 3)
                column = 2;

            //printf("Debug - Row: %d, Column: %d\n", row, column);

            // Valid - odd, 1-9, unused
            if (number%2!=0 && number>=1 && number<=9 && position>=1 && position<=9 && numbers[number-1]==0 && gameBoard[row][column] == 0){
                userInputIsValid = 1;
            }else{
                //Invalid Input, ask the user again for input
                userInputIsValid = 0;
                //printf("Debug 1 - %d", userInputIsValid);
                printf("Invalid input please enter again!\n");
            }

    }


    //Only if user input is valid, put the number on board
    if (position==9)
        gameBoard[0][2]=number;
    else if(position==8)
        gameBoard[0][1]=number;
    else if(position==7)
        gameBoard[0][0]=number;
    else if(position==6)
        gameBoard[1][2]=number;
    else if(position==5)
        gameBoard[1][1]=number;
    else if(position==4)
        gameBoard[1][0]=number;
    else if(position==3)
        gameBoard[2][2]=number;
    else if(position==2)
        gameBoard[2][1]=number;
    else if(position==1)
        gameBoard[2][0]=number;



    numbers[number-1]=1;

   }
    if(currentPlayer==2)
    {
        //AI plays here
        int i;
        for(i=0;i<3;i++){
            if(i == 0){
                if(gameBoard[i][0] != 0){
                    if(gameBoard[1][1] != 0){
                        int number = ((15-(gameBoard[i][0] + gameBoard[1][1])) % 10);
                        if(number == 0)
                            number++;
                        if(numbers[number-1] == 0){
                            if(gameBoard[2][2] == 0){
                                gameBoard[2][2] = number;
                                return;
                            }
                        }
                    }else if(gameBoard[2][2] != 0){
                        int number = ((15-(gameBoard[0][0] + gameBoard[2][2]))% 10);
                        if(number == 0)
                            number++;
                        if(numbers[number-1] == 0){
                            gameBoard[1][1] = number;
                            return;
                        }
                    }
                }else if(gameBoard[1][1] != 0){
                    if(gameBoard[2][2] != 0){
                        int number = ((15-(gameBoard[1][1] + gameBoard[2][2]))% 10);
                        if(number == 0)
                            number++;
                        if(numbers[number-1] == 0){
                            gameBoard[0][0] = number;
                            return;
                        }
                    }
                }
            }
            if(i == 2){
                if(gameBoard[i][0] != 0){
                    if(gameBoard[1][1] != 0){
                        int number = ((15-(gameBoard[i][0] + gameBoard[1][1])% 10));
                        if(number == 0)
                            number++;
                        if(numbers[number-1] == 0){
                            if(gameBoard[0][2] == 0){
                                gameBoard[0][2] = number;
                                return;
                            }
                        }
                    }else if(gameBoard[0][2] != 0){
                        int number = ((15-(gameBoard[0][0] + gameBoard[0][2])% 10));
                        if(number == 0)
                            number++;
                        if(numbers[number-1] == 0){
                            gameBoard[1][1] = number;
                            return;
                        }
                    }
                }else if(gameBoard[1][1] != 0){
                    if(gameBoard[0][2] != 0){
                        int number = ((15-(gameBoard[1][1] + gameBoard[0][2])% 10));
                        if(number == 0)
                            number++;
                        if(numbers[number-1] == 0){
                            gameBoard[2][0] = number;
                            return;
                        }
                    }
                }
            }
            else if(gameBoard[i][0] != 0){
                if(gameBoard[i][1] != 0){
                    int number = ((15-(gameBoard[i][0] + gameBoard[i][1])% 10));
                    if(number == 0)
                        number++;
                    if(numbers[number-1] == 0){
                        if(gameBoard[i][2] == 0){
                            gameBoard[i][2] = number;
                            return;
                        }
                    }
                }
            }
            else if(gameBoard[i][1] != 0){
                if(gameBoard[i][2] != 0){
                    int number = ((15-(gameBoard[i][1] + gameBoard[i][2])% 10));
                    if(number == 0)
                        number++;
                    if(numbers[number-1] == 0){
                        gameBoard[i][0] = number;
                        return;
                    }
                }
            }
            else if(gameBoard[i][2] != 0){
                int number = ((15-(gameBoard[i][2])% 10));
                if(number == 0)
                    number++;
                if(numbers[number-1] == 0){
                    gameBoard[i][0] = number;
                    return;
                }
            }
        }
        for (int i=0; i<3; i++) {
            if(gameBoard[0][i] != 0){
                if(gameBoard[1][i] != 0){
                    int number = ((15-(gameBoard[0][i] + gameBoard[1][i]))% 10);
                    if(number == 0)
                        number++;
                    if(numbers[number-1] == 0){
                        if(gameBoard[2][i] == 0){
                            gameBoard[2][i] = number;
                            return;
                        }
                    }
                }
            }
            else if(gameBoard[1][i] != 0){
                if(gameBoard[2][i] != 0){
                    int number = ((15-(gameBoard[1][i] + gameBoard[2][i]))% 10);
                    if(number == 0)
                        number++;
                    if(numbers[number-1] == 0){
                        gameBoard[0][i] = number;
                        return;
                    }
                }
            }
            else if(gameBoard[2][i] != 0){
                int number = ((15-(gameBoard[2][i]))% 10);
                if(number == 0)
                    number++;
                if(numbers[number-1] == 0){
                    gameBoard[0][i] = number;
                    return;
                }
            }
        }
        int number = 1;
        while(numbers[number-1] != 0){
            number++;
        }

        numbers[number-1] = 1;
        int row=0,column=0;
        while (gameBoard[row][column] != 0) {
            column++;
            if(column == 3)
                row++;
            if(row == 3)
                return;
        }
        gameBoard[row][column] = number;

    }
}



/* Return 1 if there is a winner in the game, otherwise return 0.
   Note: the winner is the current player indicated in main(). */
int hasWinner(int gameBoard[3][3]){
    int i,j;
    int sum;
    int flag=0;
    int empty;
    for(j=0;j<=2;j++){
        sum=0;
        empty=0;

    for(i=0;i<=2;i++){
        if(gameBoard[i][j]==0)
            empty++;
        sum= sum+ gameBoard[i][j];
        //printf("%d\t" ,sum);


    }
    //printf("%d is checking vertically\n",sum);
    if (sum == 15 && empty==0 )
        flag++;
        else
        continue;
    }
    for(i=0;i<=2;i++){
    sum=0;
    empty=0;
        for(j=0;j<=2;j++){
            if(gameBoard[i][j]==0)
            empty++;
            sum= sum+ gameBoard[i][j];

        }
    // printf("%d is checking horizontally\n",sum);
        if (sum == 15 && empty==0)
            flag++;
            else
            continue;
        }
        if(gameBoard[0][0]+gameBoard[1][1]+gameBoard[2][2]==15 && gameBoard[0][0]!=0 && gameBoard[1][1]!=0 && gameBoard[2][2]!=0)
        flag++;

        if(gameBoard[0][2]+gameBoard[1][1]+gameBoard[2][0]==15 && gameBoard[0][2]!=0 && gameBoard[1][1]!=0 && gameBoard[2][0]!=0)
        flag++;

    //printf("%d is the flag number",flag);

        if (flag==0)
           return 0;
        else
        return 1;
}






/* Return 1 if the game board is full, otherwise return 0. */


int isFull(int gameBoard[3][3]){


    int i;
    int j;
    int count=0;
    for(i=0;i<=2;i++){

        for(j=0;j<=2;j++){
            if(gameBoard[i][j]==0)
                count++;
            else
                continue;
                }
        }

        if(count==0)

            return 1;

        else
            return 0;


}

/* The main function */

int main()
{
    int gameBoard[3][3]={0};
    int numbers[9] = {0};           /* An array to record which numbers are used by the players.
                                       Example: if numbers[0] is 1, the number 1 is used
                                                if numbers[1] is 0, the number 2 is not used
                                                if numbers[8] is 1, the number 9 is used */
    int currentPlayer=1;              // 1: Player 1             2: Player 2
    int gameContinue=1;
    int x,y;

    while(gameContinue==1){
        if(currentPlayer==3)
            currentPlayer=1;
            x=isFull(gameBoard);
            y=hasWinner(gameBoard);
        if(x==0 && y==0){
            printInfo(gameBoard, numbers);
            placeNumber(gameBoard, numbers,currentPlayer);

            currentPlayer++;

        }
        else{
        gameContinue==0;
            break;
        }
    }

      if(x==1 && y==0)
        printf("Draw game");

      else if(y==1){
        //printf("\n%d is the current player",currentPlayer);
        if(currentPlayer==2)
        printf("\nCongratulations! Player 1 wins!\n");
        else if(currentPlayer==1)
            printInfo(gameBoard, numbers);
            printf("\nComputer wins!\n");
      }


  return 0;
}


